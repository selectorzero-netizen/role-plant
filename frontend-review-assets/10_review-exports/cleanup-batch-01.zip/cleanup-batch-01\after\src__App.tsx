﻿import React from 'react';
import { createBrowserRouter, RouterProvider, Navigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { LoginPage } from './pages/MemberPages';
import { AuthLayout } from './components/Shared';
import { AdminLayout, AdminDashboard, AdminUsers, AdminApplications } from './pages/AdminPages';
import { AdminPlants } from './pages/AdminPlants';
import { AdminPlantEditor } from './pages/AdminPlantEditor';
import { AdminSettings } from './pages/AdminSettings';
import { AdminContentList, AdminContentEditor } from './pages/AdminContentEditor';
import { AdminInquiries } from './pages/AdminInquiries';
import { AdminPosts } from './pages/AdminPosts';
import { AdminPostEditor } from './pages/AdminPostEditor';
import { AdminMedia } from './pages/AdminMedia';
import { AdminTaxonomy } from './pages/AdminTaxonomy';

// CLEANUP_BATCH_01
// Legacy public frontend shell detached from active router.
// Old public pages are intentionally removed from the live app entry.
// /login and /member are temporarily kept only as transitional holds until Batch 02.

const FrontendHoldPage = () => (
  <div className="min-h-screen bg-[#F7F7F5] text-[#1A1A1A] flex items-center justify-center px-6">
    <div className="max-w-2xl w-full text-center">
      <p className="text-[11px] tracking-[0.25em] uppercase text-[#1A1A1A]/40 mb-4">Cleanup Batch 01</p>
      <h1 className="text-4xl md:text-5xl font-light tracking-tight mb-6">Legacy Public Frontend Detached</h1>
      <p className="text-sm md:text-base leading-7 text-[#1A1A1A]/65 mb-10">
        舊公開前台已從主入口移除。這個階段只保留清理用的暫存入口與後台管理路徑，
        新前台將在後續批次與新規格中重新建立。
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Link to="/login" className="px-6 py-3 bg-[#1A1A1A] text-white text-xs tracking-[0.2em] uppercase hover:bg-[#3A4A37] transition-colors">
          Login Hold
        </Link>
        <Link to="/admin" className="px-6 py-3 border border-[#1A1A1A]/20 text-xs tracking-[0.2em] uppercase hover:bg-[#1A1A1A]/5 transition-colors">
          Admin
        </Link>
      </div>
    </div>
  </div>
);

const MemberHoldPage = () => (
  <div className="min-h-screen bg-[#F7F7F5] text-[#1A1A1A] flex items-center justify-center px-6">
    <div className="max-w-2xl w-full text-center">
      <p className="text-[11px] tracking-[0.25em] uppercase text-[#1A1A1A]/40 mb-4">Cleanup Batch 01</p>
      <h1 className="text-3xl md:text-4xl font-light tracking-tight mb-6">Legacy Member Flow On Hold</h1>
      <p className="text-sm md:text-base leading-7 text-[#1A1A1A]/65 mb-10">
        舊的 /member 仍暫時存在，但只作為清理過渡使用。真正的會員、追蹤、申請與售後流程，
        會在後續批次重新整理。
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Link to="/" className="px-6 py-3 border border-[#1A1A1A]/20 text-xs tracking-[0.2em] uppercase hover:bg-[#1A1A1A]/5 transition-colors">
          Back
        </Link>
        <Link to="/admin" className="px-6 py-3 bg-[#1A1A1A] text-white text-xs tracking-[0.2em] uppercase hover:bg-[#3A4A37] transition-colors">
          Admin
        </Link>
      </div>
    </div>
  </div>
);

const ProtectedRoute = ({
  children,
  requireRole
}: {
  children: React.ReactNode,
  requireRole?: string | string[]
}) => {
  const { userProfile, isAuthReady, authError, retryInit } = useAuth();
  const location = useLocation();

  if (authError) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-[#F7F7F5] px-6">
        <h1 className="text-2xl mb-2 font-light tracking-widest text-red-800">登入驗證失敗</h1>
        <p className="text-sm tracking-widest text-[#1A1A1A]/50 mb-8">無法載入會員資料 (連線超時或初始失敗)。</p>
        <div className="flex gap-4">
          <button onClick={retryInit} className="px-6 py-3 bg-[#1A1A1A] text-white text-xs tracking-widest hover:bg-[#3A4A37] transition-colors">
            重新嘗試
          </button>
          <a href="/login" className="px-6 py-3 border border-[#1A1A1A]/20 text-xs tracking-widest hover:bg-[#1A1A1A]/5 transition-colors">
            返回登入
          </a>
        </div>
      </div>
    );
  }

  if (!isAuthReady) {
    return <div className="h-screen flex items-center justify-center text-sm tracking-widest uppercase">載入權限中...</div>;
  }

  if (!userProfile) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (requireRole) {
    const roles = Array.isArray(requireRole) ? requireRole : [requireRole];
    const currentRole = userProfile.role || '';
    const hasRole = roles.includes(currentRole) || currentRole === 'super_admin';

    if (!hasRole) {
      return <Navigate to="/member" replace />;
    }
  }

  return children;
};

const router = createBrowserRouter([
  {
    path: '/',
    element: <FrontendHoldPage />
  },
  {
    path: '/login',
    element: <AuthLayout><LoginPage /></AuthLayout>
  },
  {
    path: '/member',
    element: <ProtectedRoute><MemberHoldPage /></ProtectedRoute>
  },

  // Admin routes remain active in Batch 01.
  {
    path: '/admin',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminDashboard /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/plants',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminPlants /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/plants/:id',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminPlantEditor /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/users',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminUsers /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/members',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminUsers /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/applications',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminApplications /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/inquiries',
    element: <ProtectedRoute requireRole="admin"><AdminLayout><AdminInquiries /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/posts',
    element: <ProtectedRoute requireRole={['admin', 'editor']}><AdminLayout><AdminPosts /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/posts/:id',
    element: <ProtectedRoute requireRole={['admin', 'editor']}><AdminLayout><AdminPostEditor /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/media',
    element: <ProtectedRoute requireRole={['admin', 'editor']}><AdminLayout><AdminMedia /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/content',
    element: <ProtectedRoute requireRole={['admin', 'editor']}><AdminLayout><AdminContentList /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/content/:pageId',
    element: <ProtectedRoute requireRole={['admin', 'editor']}><AdminLayout><AdminContentEditor /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/settings',
    element: <ProtectedRoute requireRole="super_admin"><AdminLayout><AdminSettings /></AdminLayout></ProtectedRoute>
  },
  {
    path: '/admin/taxonomy',
    element: <ProtectedRoute requireRole="super_admin"><AdminLayout><AdminTaxonomy /></AdminLayout></ProtectedRoute>
  },
  {
    path: '*',
    element: <Navigate to="/" replace />
  }
]);

export default function App() {
  return <RouterProvider router={router} />;
}
