import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { SafeImage, plantDatabase as fallbackDatabase } from '../components/Shared';
import { useAuth } from '../AuthContext';
import { favoritesService } from '../services/favoritesService';
import { memberApplicationService } from '../services/memberApplicationService';
import { plantService } from '../services/plantService';
import { Taxonomy } from '../types';
import { taxonomyService } from '../services/taxonomyService';
import { Filter } from 'lucide-react';

export function CollectionPage() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState('All');
  const [catFilter, setCatFilter] = useState('all');
  const [plants, setPlants] = useState<any[]>([]);
  const [categories, setCategories] = useState<Taxonomy[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [livePlants, catData] = await Promise.all([
          plantService.getPublicPlants(),
          taxonomyService.getByType('plant_category')
        ]);
        
        if (livePlants.length > 0) {
          setPlants(livePlants);
        } else {
          setPlants(fallbackDatabase);
        }
        setCategories(catData);
      } catch (error) {
        console.error("Error fetching collection data:", error);
        setPlants(fallbackDatabase);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const statusTabs = [
    { id: 'All', name: '全部', desc: '完整的選拔檔案紀錄。' },
    { id: 'Available', name: '可釋出', desc: '經過完整休眠與生長季觀察，確認健康完成度，目前狀態穩定可供收藏的個體。' },
    { id: 'Observation', name: '觀察中', desc: '正在進行型態調整或剛換盆，需要更多時間確認培育未來性的個體，暫不釋出。' },
    { id: 'Archived', name: '已收藏', desc: '具有特殊表現或已由其他收藏者養護的歷史檔案，保留作為判讀與標準建立的參考。' }
  ];

  const statusMap: Record<string, string> = {
    '培育中': 'Observation',
    'exhibiting': 'Available',
    'sold': 'Archived',
    'hidden': 'Observation',
    '可售': 'Available',
    '已售': 'Archived'
  };

  const filteredPlants = plants.filter(p => {
    // Status Filter
    const mappedStatus = statusMap[p.status] || p.status;
    const statusMatch = filter === 'All' || mappedStatus === filter;
    
    // Taxonomy Category Filter
    const catMatch = catFilter === 'all' || p.category === catFilter;
    
    return statusMatch && catMatch;
  });

  const currentStatus = statusTabs.find(c => c.id === filter);

  return (
    <div className="bg-[#EAE8E3] min-h-screen text-[#1A1A1A] pb-32">
      <div className="max-w-screen-2xl mx-auto px-6 md:px-12 pt-16 lg:pt-32">
         {/* Title Area */}
         <div className="mb-16 md:mb-32">
           <h1 className="text-5xl md:text-7xl font-light tracking-tighter mb-4">選拔檔案</h1>
           <p className="text-xs tracking-[0.3em] uppercase text-[#1A1A1A]/40 font-mono">Role Plant Archive</p>
         </div>

         <div className="flex flex-col lg:flex-row gap-12 lg:gap-24 relative">
            
            {/* Left/Top: Filters (Desktop Sticky sidebar / Mobile Dropdowns) */}
            <div className="lg:w-1/4 lg:sticky lg:top-32 self-start flex flex-col gap-12">
               
               {/* Mobile Dropdowns */}
               <div className="flex lg:hidden flex-col sm:flex-row gap-4 w-full">
                 <select 
                   value={filter} 
                   onChange={(e) => setFilter(e.target.value)}
                   className="w-full bg-transparent border border-[#1A1A1A]/10 text-[10px] sm:text-xs py-4 px-4 tracking-widest uppercase appearance-none focus:outline-none focus:border-[#1A1A1A]/30 font-mono"
                 >
                   {statusTabs.map(cat => (
                     <option key={cat.id} value={cat.id}>{cat.name} / {cat.id.toUpperCase()}</option>
                   ))}
                 </select>
                 
                 <select 
                   value={catFilter} 
                   onChange={(e) => setCatFilter(e.target.value)}
                   className="w-full bg-transparent border border-[#1A1A1A]/10 text-[10px] sm:text-xs py-4 px-4 tracking-widest uppercase appearance-none focus:outline-none focus:border-[#1A1A1A]/30 font-mono"
                 >
                   <option value="all">全部屬系 ALL</option>
                   {categories.map(cat => (
                     <option key={cat.id} value={cat.key}>{cat.label}</option>
                   ))}
                 </select>
               </div>

               {/* Desktop Fixed Text List */}
               <div className="hidden lg:block space-y-12">
                 <div>
                   <h3 className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/50 font-mono mb-6">Status / 狀態</h3>
                   <ul className="space-y-4">
                     {statusTabs.map(cat => (
                       <li key={cat.id}>
                         <button 
                           onClick={() => setFilter(cat.id)}
                           className={`text-xs tracking-widest transition-colors block text-left w-full ${filter === cat.id ? 'text-[#1A1A1A] font-medium' : 'text-[#1A1A1A]/30 hover:text-[#1A1A1A]/60'}`}
                         >
                           {cat.name} <span className="text-[10px] ml-2 font-mono">{cat.id.toUpperCase()}</span>
                         </button>
                       </li>
                     ))}
                   </ul>
                 </div>

                 <div>
                   <h3 className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/50 font-mono mb-6">Category / 屬系</h3>
                   <ul className="space-y-4">
                     <li>
                       <button 
                         onClick={() => setCatFilter('all')}
                         className={`text-xs tracking-widest transition-colors block text-left w-full ${catFilter === 'all' ? 'text-[#1A1A1A] font-medium' : 'text-[#1A1A1A]/30 hover:text-[#1A1A1A]/60'}`}
                       >
                         全部 <span className="text-[10px] ml-2 font-mono uppercase">ALL</span>
                       </button>
                     </li>
                     {categories.map(cat => (
                       <li key={cat.id}>
                         <button 
                           onClick={() => setCatFilter(cat.key)}
                           className={`text-xs tracking-widest transition-colors block text-left w-full uppercase ${catFilter === cat.key ? 'text-[#1A1A1A] font-medium' : 'text-[#1A1A1A]/30 hover:text-[#1A1A1A]/60'}`}
                         >
                           {cat.label}
                         </button>
                       </li>
                     ))}
                   </ul>
                 </div>
               </div>
            </div>

            {/* Right: Archive List */}
            <div className="lg:w-3/4 min-h-[60vh]">
               {loading ? (
                  <div className="flex justify-center items-center h-64 border border-[#1A1A1A]/10 border-dashed">
                    <span className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/30 font-mono">Reading Archive...</span>
                  </div>
               ) : filteredPlants.length === 0 ? (
                  <div className="flex flex-col justify-center items-center h-64 border border-[#1A1A1A]/10">
                    <span className="text-xs tracking-widest uppercase text-[#1A1A1A]/40 mb-2">查無檔案資料</span>
                    <span className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/20 font-mono">0 RECORDS FOUND</span>
                  </div>
               ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-x-8 gap-y-24">
                    {filteredPlants.map((item) => {
                      const hasImages = item.images && item.images.length > 0;
                      const coverImage = item.coverImageUrl || (hasImages ? item.images.find((i:any) => i.isCover)?.url || item.images[0].url : item.image);
                      
                      // Create a short objective summary out of its properties
                      const shortDesc = [item.size, item.localName, item.grade].filter(Boolean).join(' • ');

                      return (
                        <div key={item.id} className="group cursor-pointer flex flex-col" onClick={() => navigate(`/collection/${item.id}`)}>
                          {/* Image Box */}
                          <div className="aspect-[3/4] bg-[#DCD7C9] overflow-hidden mb-6 relative border border-[#1A1A1A]/5">
                            {coverImage ? (
                              <img src={coverImage} alt={item.name} className="w-full h-full object-cover filter contrast-110 saturate-50" />
                            ) : (
                              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                                <span className="text-[10px] text-[#1A1A1A]/20 font-mono uppercase tracking-widest mb-2">S/N: {item.serialNumber || 'MISSING'}</span>
                                <span className="text-sm font-medium text-[#1A1A1A]/30">{item.name}</span>
                              </div>
                            )}
                            
                            {/* Archived Label on Image */}
                            {(item.status === '已售' || item.status === 'sold' || item.status === 'Archive') && (
                              <div className="absolute top-4 right-4 bg-[#EAE8E3]/90 text-[#1A1A1A] text-[10px] uppercase tracking-widest px-2 py-1 font-mono">
                                Archived
                              </div>
                            )}
                          </div>
                          
                          {/* Profile Data */}
                          <div className="flex flex-col flex-grow">
                             <div className="flex justify-between items-start mb-3">
                               <p className="text-[10px] text-[#1A1A1A]/40 font-mono uppercase tracking-widest">{item.serialNumber || item.id.substring(0,6)}</p>
                               <span className="text-[10px] tracking-widest text-[#1A1A1A]/50 border border-[#1A1A1A]/10 px-1.5 py-0.5 uppercase">{item.status}</span>
                             </div>
                             
                             <h3 className="font-light text-xl mb-2 leading-tight">{item.name}</h3>
                             
                             <p className="text-[10px] text-[#1A1A1A]/50 font-light leading-relaxed flex-grow line-clamp-1 mb-8 uppercase tracking-widest">
                               {shortDesc || item.scientificName || 'UNKNOWN-ATTRIBUTES'}
                             </p>
                             
                             <div className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/40 group-hover:text-[#1A1A1A] transition-colors pt-4 flex justify-between items-center mt-auto border-t border-[#1A1A1A]/10">
                               <span>檢閱檔案</span>
                               <span className="font-mono">ENTER ↵</span>
                             </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
               )}
            </div>
         </div>
      </div>
    </div>
  );
}

export function SinglePlantPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [plant, setPlant] = useState<any>(null);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    const fetchPlant = async () => {
      if (!id) return;
      try {
        // Use plantService for consistency—single source of truth
        const data = await plantService.getPlantById(id);
        if (data) {
          setPlant(data);
        } else {
          // Fallback to static mock data for legacy IDs
          const localPlant = fallbackDatabase.find(p => p.id === id);
          setPlant(localPlant || null);
        }
      } catch (error) {
        console.error("Error fetching plant:", error);
        const localPlant = fallbackDatabase.find(p => p.id === id);
        setPlant(localPlant || null);
      } finally {
        setFetching(false);
      }
    };
    fetchPlant();
  }, [id]);

  const handleApply = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (userProfile?.status === 'pending') {
      alert('您的帳號尚在審核中，無法送出申請。');
      return;
    }
    setLoading(true);
    try {
      await memberApplicationService.createApplication({
        userId: user.uid,
        plantId: plant.id,
        requestType: 'application',
        status: 'pending'
      });
      alert('申請已送出，我們將盡快與您聯繫。');
      navigate('/member');
    } catch (error) {
      console.error("Error submitting application:", error);
      alert('申請失敗，請稍後再試。');
    } finally {
      setLoading(false);
    }
  };

  const handleTrack = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (userProfile?.status === 'pending') {
      alert('您的帳號尚在審核中，無法加入追蹤。');
      return;
    }
    
    const isTracked = userProfile?.favorites?.includes(plant.id);
    if (isTracked) {
      navigate('/member');
      return;
    }

    setLoading(true);
    try {
      await favoritesService.addFavorite(user.uid, plant.id);
      navigate('/member');
    } catch (error) {
      console.error("Error tracking plant:", error);
      alert('操作失敗，請稍後再試。');
    } finally {
      setLoading(false);
    }
  };

  const renderCTA = () => {
    if (!plant) return null;
    const isTracked = userProfile?.favorites?.includes(plant.id);
    
    // Map Firestore status to categories
    const statusMap: Record<string, string> = {
      '培育中': 'Observation',
      '可申請': 'Available',
      '可售': 'Available',
      '保留中': 'Observation',
      '已售': 'Archived',
      'Archive': 'Archived'
    };
    
    const mappedStatus = statusMap[plant.status] || plant.status;

    switch (mappedStatus) {
      case 'Available':
        return (
          <button onClick={handleApply} disabled={loading} className="w-full bg-[#1A1A1A] text-[#EAE8E3] py-5 text-xs tracking-widest uppercase hover:bg-[#2A2A2A] transition-colors disabled:opacity-50 border border-[#1A1A1A]">
            {loading ? '處理中...' : '提交檔案檢閱與申請'}
          </button>
        );
      case 'Observation':
        return (
          <button onClick={handleTrack} disabled={loading} className={`w-full py-5 text-xs tracking-widest uppercase transition-colors disabled:opacity-50 ${isTracked ? 'bg-[#1A1A1A] text-[#EAE8E3]' : 'border border-[#1A1A1A]/20 text-[#1A1A1A] hover:border-[#1A1A1A]'}`}>
            {loading ? '處理中...' : (isTracked ? '追蹤名錄已收錄' : '寫入個人追蹤名錄')}
          </button>
        );
      case 'Archived':
      default:
        return (
           <div className="w-full text-center border-t border-b border-[#1A1A1A]/10 py-5">
             <span className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/40 font-mono">STATUS: {plant.status.toUpperCase()} (檔案已封存)</span>
           </div>
        );
    }
  };

  if (fetching) {
    return <div className="min-h-screen bg-[#EAE8E3] flex justify-center items-center text-[#1A1A1A]/50 text-xs tracking-widest uppercase font-mono">Reading Data...</div>;
  }

  if (!plant) {
    return <div className="min-h-screen bg-[#EAE8E3] flex justify-center items-center text-[#1A1A1A]/50 text-xs tracking-widest uppercase font-mono">No Records Found.</div>;
  }

  // 1. 主圖區 (Main Image Area) fallback logic
  const hasImages = plant.images && plant.images.length > 0;
  const coverImage = plant.coverImageUrl || (hasImages ? plant.images.find((i:any) => i.isCover)?.url || plant.images[0].url : plant.image);

  return (
    <div className="bg-[#EAE8E3] min-h-screen text-[#1A1A1A] pb-32">
      
      {/* Navbar/Header Return */}
      <div className="px-6 md:px-12 py-8 flex justify-between items-center border-b border-[#1A1A1A]/10">
        <button onClick={() => navigate('/collection')} className="flex items-center gap-3 text-[10px] tracking-widest uppercase text-[#1A1A1A]/50 hover:text-[#1A1A1A] transition-colors font-medium">
          <ArrowLeft size={16} /><span>返回總覽</span>
        </button>
        <span className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/40 font-mono">Role Plant Archive</span>
      </div>

      <div className="max-w-screen-2xl mx-auto px-6 md:px-12 pt-16 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24">
        
        {/* 1. 主圖區 */}
        <div className="lg:col-span-7">
          {coverImage ? (
            <div className="aspect-[4/5] md:aspect-auto md:h-[80vh] bg-[#DCD7C9] overflow-hidden sticky top-8">
               <img src={coverImage} alt={plant.name} className="w-full h-full object-cover filter contrast-110 saturate-50" />
            </div>
          ) : (
             <div className="aspect-[4/5] md:aspect-auto md:h-[80vh] bg-[#DCD7C9] flex items-center justify-center border border-[#1A1A1A]/10 sticky top-8">
               <span className="text-[10px] font-mono tracking-widest text-[#1A1A1A]/30">/ 無相片紀錄 /</span>
             </div>
          )}
        </div>

        {/* Right Column: Data & Actions */}
        <div className="lg:col-span-5 flex flex-col pt-4 md:pt-8 min-h-[80vh]">
          
          {/* 2. 基本檔案區 (Basic Profile Area) */}
          <div className="mb-16 border-b border-[#1A1A1A]/10 pb-12">
            <div className="mb-4">
              <p className="text-[10px] text-[#1A1A1A]/50 font-mono uppercase tracking-widest">S/N: {plant.serialNumber || plant.id}</p>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-light tracking-tight mb-2 leading-tight">{plant.name}</h1>
            <p className="text-sm text-[#1A1A1A]/60 italic mb-6 font-serif">{plant.scientificName}</p>
            
            <div className="grid grid-cols-2 gap-x-8 gap-y-6 mt-12 bg-[#1A1A1A]/[0.02] p-6 border border-[#1A1A1A]/5">
               {plant.localName && (
                 <div>
                   <span className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1 font-mono">Local Name</span>
                   <span className="text-sm font-medium">{plant.localName}</span>
                 </div>
               )}
               {plant.category && (
                 <div>
                   <span className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1 font-mono">Category</span>
                   <span className="text-sm font-medium flex items-center gap-2">
                     <span className="w-1.5 h-1.5 rounded-full bg-[#1A1A1A]"></span>
                     {plant.category}
                   </span>
                 </div>
               )}
               {plant.size && (
                 <div className="min-w-0">
                   <span className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1 font-mono">Size</span>
                   <span className="text-sm font-light block truncate" title={plant.size}>{plant.size}</span>
                 </div>
               )}
               {plant.source && (
                 <div>
                   <span className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1 font-mono">Source</span>
                   <span className="text-sm font-light">{plant.source}</span>
                 </div>
               )}
               {plant.grade && (
                 <div>
                   <span className="block text-[10px] uppercase tracking-widest text-[#1A1A1A]/40 mb-1 font-mono">Grade</span>
                   <span className="text-sm font-mono">{plant.grade}</span>
                 </div>
               )}
            </div>
          </div>

          {/* 3. 判讀焦點區 (Evaluation Focus Area) */}
          {(plant.stats?.expression || plant.stats?.balance || plant.stats?.proportion || plant.details?.summary || plant.description) && (
            <div className="mb-16 space-y-8 border-b border-[#1A1A1A]/10 pb-12">
              <h2 className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/50 font-mono flex items-center gap-4">
                Evaluation <span className="flex-1 h-px bg-[#1A1A1A]/10"></span>
              </h2>
              
              {plant.stats && (plant.stats.expression || plant.stats.balance || plant.stats.proportion) && (
                <div className="grid grid-cols-3 gap-px bg-[#1A1A1A]/10 border border-[#1A1A1A]/10">
                  {plant.stats.expression ? (
                    <div className="bg-[#EAE8E3] p-4 text-center">
                      <p className="text-[10px] uppercase tracking-wider text-[#1A1A1A]/50 mb-2">龜甲表現</p>
                      <p className="font-mono text-base">{plant.stats.expression}</p>
                    </div>
                  ) : <div className="bg-[#EAE8E3]"></div>}
                  {plant.stats.balance ? (
                    <div className="bg-[#EAE8E3] p-4 text-center">
                      <p className="text-[10px] uppercase tracking-wider text-[#1A1A1A]/50 mb-2">面相平衡</p>
                      <p className="font-mono text-base">{plant.stats.balance}</p>
                    </div>
                  ) : <div className="bg-[#EAE8E3]"></div>}
                  {plant.stats.proportion ? (
                    <div className="bg-[#EAE8E3] p-4 text-center">
                      <p className="text-[10px] uppercase tracking-wider text-[#1A1A1A]/50 mb-2">塊根比例</p>
                      <p className="font-mono text-base">{plant.stats.proportion}</p>
                    </div>
                  ) : <div className="bg-[#EAE8E3]"></div>}
                </div>
              )}

              {(plant.details?.summary || plant.description) && (
                <p className="text-[#1A1A1A]/70 font-light leading-relaxed text-sm">
                  {plant.details?.summary || plant.description}
                </p>
              )}
            </div>
          )}

          {/* 4. 狀態紀錄區 (Status Record Area) */}
          {(plant.details?.suitableFor || plant.details?.cultivationNotes) && (
            <div className="mb-16 space-y-8 border-b border-[#1A1A1A]/10 pb-12">
               <h2 className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/50 font-mono flex items-center gap-4">
                Records <span className="flex-1 h-px bg-[#1A1A1A]/10"></span>
              </h2>
              
              {plant.details?.suitableFor && (
                <div>
                  <h3 className="text-[10px] font-mono mb-2 tracking-widest text-[#1A1A1A]/40 uppercase">適合對象</h3>
                  <p className="text-[#1A1A1A]/70 font-light leading-relaxed text-sm">{plant.details.suitableFor}</p>
                </div>
              )}
              {plant.details?.cultivationNotes && (
                <div>
                  <h3 className="text-[10px] font-mono mb-2 tracking-widest text-[#1A1A1A]/40 uppercase">培育提醒</h3>
                  <p className="text-[#1A1A1A]/70 font-light leading-relaxed text-sm">{plant.details.cultivationNotes}</p>
                </div>
              )}
            </div>
          )}

          {/* 5. 申請 / 追蹤 CTA */}
          <div className="mt-auto">
            {renderCTA()}

            {/* Admin Backdoor */}
            {(userProfile?.role === 'admin' || userProfile?.role === 'editor') && (
              <div className="mt-16 pt-8 border-t border-[#1A1A1A]/10 text-right">
                <button onClick={() => navigate(`/admin/plants/${plant.id}`)} className="text-[10px] tracking-widest uppercase text-[#1A1A1A]/20 hover:text-[#1A1A1A] transition-colors font-mono">
                  [ System: Edit Profile ]
                </button>
              </div>
            )}
          </div>
          
        </div>
      </div>
    </div>
  );
}
